var express = require('express');
var router = express.Router();

router.get('/', function(request, response){
    console.log('content manager home page requested with get method!');
    var data = {
        username: request.body.username
    }
    response.render('contentManager/home/index', data);
});

router.get('/viewProfile', function(request, response){
    console.log('content manager profile page requested with post method!');
    response.render('contentManager/profile/viewProfile');
});

router.get('/index', function(request, response){
    console.log('content manager search page requested with post method!');
    response.render('contentManager/search/index');
});

router.get('/contentRequest', function(request, response){
    console.log('content manager search page requested with post method!');
    response.render('contentManager/contentView/contentRequest');
});

module.exports = router;