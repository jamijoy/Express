// declaration
var express = require('express');
var expSession = require('express-session');
var ejs = require('ejs');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var mySql = require('mysql');

// var index = require('./controllers/index');
// var home = require('./controllers/home');
var login = require('./controllers/login');
var logout = require('./controllers/logout');
var register = require('./controllers/registration');

var home = require('./controllers/accountManager/home');
var profile = require('./controllers/accountManager/profile');

var contentManagerHome = require('./controllers/contentManager/home');
var contentManagerProfile = require('./controllers/contentManager/profile');

var app = express();

// configuration
app.set('view engine', 'ejs');

//middleware
app.use(bodyParser.urlencoded({extended:true}));
app.use(expSession({secret:'Hello Express', saveUninitialized: true, resave:false}));

// app.use('/', index);
// app.use('/home', home);
app.use('/', login);
app.use('/logout', logout);
app.use('/register', register);

app.use('/accountManager/home', home);
app.use('/accountManager/profile', profile);

app.use('/contentManager/home', contentManagerHome);
app.use('/contentManager/profile', contentManagerHome);
app.use('/contentManager/contentView', contentManagerHome);
app.use('/contentManager/profile', contentManagerProfile);
app.use('/contentManager/search', contentManagerHome);

// routes

//server startup
var serverPort=3000;
app.listen(serverPort, function(){
    console.log("project server started at", serverPort);
    
});